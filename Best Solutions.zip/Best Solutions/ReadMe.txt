1. The best solution found is stored in a text file named "N.txt", where N is the number of circles. 

2. The format of solution file is as follows: 
The first line of file contains the number of circles (N), the minimum Euclidean distance between the centers of two spherical caps, and the angular diameter of circles (in degree). 
As for the remaining parts, each line contains the index of one circle, and the X-coordinate, Y-coordinate and Z-coordinate of the center of the corresponding spherical cap.