1. The checking procedure and the solution file should be located in the same directory.
2. The input parameter of the checking procedure contains only the number of unit circles (N). 