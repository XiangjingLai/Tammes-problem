#!/bin/sh
./IDNS 100 10 1000 